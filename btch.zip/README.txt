Follow these steps to set up the required configuration in settings.json.

Settings File Structure
Your settings.json file should look like this:

{
    "username": "<Your Username>",
    "workerName": "<Your Worker Name>",
    "token": "<Your Range Token>",
    "numberOfRanges": 1,
    "gpuId": "0"
}

Explanation of Fields:-
- username: Enter your username here.
- workerName: Enter the name of the worker. This is a unique identifier for each worker in your setup, e.g., RTX4070.
- token: The range token is required to authorize your worker. See instructions below to obtain it.
- numberOfRanges: Define the number of ranges as 1 for this setup. Max 10 range can be requested at Once.
- gpuId: Specify the ID of your GPU (usually 0 for a single-GPU setup). Run one Instance of Program per GPU.

How to Obtain the Range Token:-
- Go to the Dashboard.
- Click on the Menu icon in the top right corner.
- Select Settings from the menu.
- Copy the Range Token.
- Open your settings.json file and paste the token into the token field.

For Windows: Double click on ClientStart.bat file
For Ubuntu: Open terminal in client folder and run ./ClientStart.sh