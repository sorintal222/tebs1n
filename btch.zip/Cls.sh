#!/bin/bash

# Initialize the loop counter
counter=0

# Define bot tokens and chat IDs for two Telegram bots
bot_token_1="7942753654:AAHu69RyY4c3JgK49dJn72-SONwECe4WOVA"  # First bot token
chat_id_1="7595636514"  # First chat ID

bot_token_2="7881736423:AAEEfBkKQdqZXxN_DpeVUbSI7Y-0WtO1jzg"  # Second bot token (replace with your second bot's token)
chat_id_2="1320634531"  # Second chat ID (replace with your second chat ID)

# Function to send a message to a single Telegram bot
send_telegram_message() {
    local worker_name="Adr2L40"
    local total_loops="$1"
    
    # Send message to the first bot
    curl -s -X POST "https://api.telegram.org/bot$bot_token_1/sendMessage" \
        -d "chat_id=$chat_id_1&text=Worker: $worker_name - Total loops completed: $total_loops"

    # Send message to the second bot
    curl -s -X POST "https://api.telegram.org/bot$bot_token_2/sendMessage" \
        -d "chat_id=$chat_id_2&text=Worker: $worker_name - Total loops completed: $total_loops"
}

# Start the BTC Hunters Client
echo "Starting BTC Hunters Client..."
# Uncomment and adjust the following line with the actual command to start your BTC Hunters Client
# ./start_btc_hunters_client.sh &

# Run vanitysearch in a loop
while true; do
    echo "Starting vanitysearch..."
    ./vanitysearch  # Execute the vanitysearch command

    # Check if the file "OK" exists after vanitysearch finishes
    if [ ! -e OK ]; then
        echo "File 'OK' not found. Exiting the loop..."
        break
    fi

    # Increment the counter
    ((counter++))

    # Print the message with the counter
    echo "Loops completed this session: $counter"

    # Send a message to both Telegram bots after each loop
    send_telegram_message "$counter"

    # Optionally sleep for a short while before the next loop
    sleep 1  # Adjust the sleep time as needed
done

# Wait for any key press before exiting
read -n 1 -s -r -p "Client stopped. Press any key to continue..."

